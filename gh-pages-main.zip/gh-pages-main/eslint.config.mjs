import configs from 'eslint-config-tschaub';

export default [...configs];
