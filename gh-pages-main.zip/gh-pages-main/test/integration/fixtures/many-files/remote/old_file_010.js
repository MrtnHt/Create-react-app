// This is remote/old_file_010.js file
