// This is remote/old_file_006.js file
