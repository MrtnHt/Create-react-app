// This is remote/old_file_066.js file
