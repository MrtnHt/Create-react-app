// This is remote/old_file_106.js file
