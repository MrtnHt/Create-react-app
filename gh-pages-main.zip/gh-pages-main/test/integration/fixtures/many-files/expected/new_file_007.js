// This is local/new_file_007.js file
