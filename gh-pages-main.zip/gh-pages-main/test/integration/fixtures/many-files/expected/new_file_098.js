// This is local/new_file_098.js file
