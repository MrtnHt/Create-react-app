// This is local/new_file_030.js file
