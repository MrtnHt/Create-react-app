// This is local/new_file_106.js file
