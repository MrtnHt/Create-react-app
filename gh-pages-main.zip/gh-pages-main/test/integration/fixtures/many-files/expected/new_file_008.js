// This is local/new_file_008.js file
