// This is local/new_file_095.js file
