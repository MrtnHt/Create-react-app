// This is local/new_file_002.js file
