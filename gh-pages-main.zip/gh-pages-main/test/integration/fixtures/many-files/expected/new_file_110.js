// This is local/new_file_110.js file
