// This is local/new_file_041.js file
