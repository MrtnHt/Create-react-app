// This is local/new_file_066.js file
