// This is local/new_file_043.js file
