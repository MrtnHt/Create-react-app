// This is local/new_file_076.js file
