// This is local/new_file_088.js file
