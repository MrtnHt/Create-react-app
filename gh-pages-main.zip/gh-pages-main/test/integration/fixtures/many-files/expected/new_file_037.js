// This is local/new_file_037.js file
