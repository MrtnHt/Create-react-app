// This is local/new_file_125.js file
