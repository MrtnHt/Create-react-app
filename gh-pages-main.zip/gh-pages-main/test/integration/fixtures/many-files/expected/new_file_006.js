// This is local/new_file_006.js file
