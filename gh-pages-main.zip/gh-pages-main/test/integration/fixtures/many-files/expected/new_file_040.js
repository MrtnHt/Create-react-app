// This is local/new_file_040.js file
