// This is local/new_file_038.js file
