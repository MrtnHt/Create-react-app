// This is local/new_file_073.js file
