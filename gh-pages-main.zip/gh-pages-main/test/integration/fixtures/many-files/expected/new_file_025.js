// This is local/new_file_025.js file
