// This is local/new_file_003.js file
