// This is local/new_file_123.js file
