// This is local/new_file_042.js file
