// This is local/new_file_004.js file
