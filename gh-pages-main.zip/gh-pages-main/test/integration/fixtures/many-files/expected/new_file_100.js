// This is local/new_file_100.js file
