// This is local/new_file_111.js file
