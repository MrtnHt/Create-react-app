// This is local/new_file_005.js file
