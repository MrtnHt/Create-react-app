// This is local/new_file_012.js file
