// This is local/new_file_009.js file
