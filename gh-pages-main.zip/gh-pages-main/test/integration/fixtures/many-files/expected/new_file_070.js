// This is local/new_file_070.js file
