// This is local/new_file_101.js file
