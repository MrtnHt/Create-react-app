// This is local/new_file_104.js file
