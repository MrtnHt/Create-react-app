// This is local/new_file_020.js file
