// This is local/new_file_036.js file
