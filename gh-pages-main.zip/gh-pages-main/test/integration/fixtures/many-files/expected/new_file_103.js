// This is local/new_file_103.js file
