// This is local/new_file_039.js file
