// This is local/new_file_050.js file
