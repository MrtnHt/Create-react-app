// This is local/new_file_120.js file
