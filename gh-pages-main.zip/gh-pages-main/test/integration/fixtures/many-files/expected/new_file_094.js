// This is local/new_file_094.js file
