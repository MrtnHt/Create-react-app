// This is local/new_file_023.js file
