// This is local/new_file_067.js file
