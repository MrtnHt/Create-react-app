// This is local/new_file_010.js file
