// This is local/new_file_021.js file
