// This is local/new_file_001.js file
