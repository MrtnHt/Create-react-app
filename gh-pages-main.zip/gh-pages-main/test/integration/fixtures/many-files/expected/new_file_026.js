// This is local/new_file_026.js file
