// This is local/new_file_097.js file
