// This is local/new_file_112.js file
