// This is local/new_file_102.js file
