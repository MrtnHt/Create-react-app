// This is local/new_file_116.js file
