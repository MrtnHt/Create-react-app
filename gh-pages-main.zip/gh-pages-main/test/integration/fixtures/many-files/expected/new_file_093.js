// This is local/new_file_093.js file
