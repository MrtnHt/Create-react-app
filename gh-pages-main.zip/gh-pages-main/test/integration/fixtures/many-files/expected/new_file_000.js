// This is local/new_file_000.js file
