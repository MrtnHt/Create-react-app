// This is local/new_file_105.js file
