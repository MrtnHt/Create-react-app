// This is local/new_file_122.js file
