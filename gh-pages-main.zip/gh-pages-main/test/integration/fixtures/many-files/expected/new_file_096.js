// This is local/new_file_096.js file
